# [Ice](https://marketplace.visualstudio.com/items?itemName=a5hk.ice)

A freezing cold dark theme.

Also available for [vim](/vim/colors/), [bat](/bat/), and [Windows Terminal](/windows-terminal/).

![javascript](/screenshot/javascript.png)

## How to contribute

Built using [Theme Generator](https://github.com/a5hk/theme-generator). [Contribution Guide](https://github.com/a5hk/theme-generator/blob/master/CONTRIBUTING.md)

## License

[MIT License](LICENSE)
