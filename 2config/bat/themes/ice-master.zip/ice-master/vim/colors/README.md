This is a port of [Ice](https://marketplace.visualstudio.com/items?itemName=a5hk.ice) VS Code theme for vim. Built using [Theme Generator](https://github.com/a5hk/theme-generator).

## Screenshots

![ruby](/screenshot/vim.png)
