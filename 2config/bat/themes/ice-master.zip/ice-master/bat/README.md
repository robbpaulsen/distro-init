This is a port of [Ice](https://marketplace.visualstudio.com/items?itemName=a5hk.ice) VS Code theme for bat. Built using [Theme Generator](https://github.com/a5hk/theme-generator).

## Screenshots

![ruby](../screenshot/bat.png)
