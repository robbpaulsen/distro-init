# Changelog

## 2.0.0

- Removed italic variant
- Some other minor improvments

## 1.2.0

- Fixed TypeScript highlighting

## 1.1.2

- Default error color
- Unexpected bracket color

## 1.1.0

- Customized code action color

## 1.0.1

- More contrasted colors for input options

## 1.0.0

- Customized Command Center colors

## 0.7.0

- Several changes

## 0.6.0

- Semantic highlighting
- Fewer more distinguishable colors

## 0.5.0

- Background color for folded ranges

## 0.4.2

- Fixed gallery banner color

## 0.4.1

- Added Ice contrast variant

## 0.3.0

- Updated terminal colors

## 0.2.1

- New logo

## 0.2.0

- Slightly modified colors

## 0.1.0

- Color adjustment

## 0.0.2

- Modified tab hover border

## 0.0.1

- Initial release
