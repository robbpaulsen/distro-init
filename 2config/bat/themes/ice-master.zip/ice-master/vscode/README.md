# [Ice](https://marketplace.visualstudio.com/items?itemName=a5hk.ice)

A theme that mimics the frozen and crystalline beauty of ice.

Also available for [vim](/vim/colors/), [bat](/bat/), and [Windows Terminal](/windows-terminal/). Built using [Theme Generator](https://github.com/a5hk/theme-generator)

## Screenshots

### JavaScript [(Ice)](https://vscode.dev/theme/a5hk.ice/Ice)

![javascript](/screenshot/javascript.png)

## License

[MIT License](/LICENSE)
