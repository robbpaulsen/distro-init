This is a port of [Night Coder](https://marketplace.visualstudio.com/items?itemName=a5hk.night-coder) VS Code theme for Windows Terminal. Built using [Theme Generator](https://github.com/a5hk/theme-generator)

![windows terminal](/screenshot/windows-terminal.png)
