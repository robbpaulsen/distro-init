This is a port of [Night Coder](https://marketplace.visualstudio.com/items?itemName=a5hk.night-coder) VS Code theme for Vim. Built using [Theme Generator](https://github.com/a5hk/theme-generator)

True color support is required.

## Screenshots

### Ruby

Screenshot of Windows Terminal (and WSL)

|         Night Coder Ember          |         Night Coder Flame          |
| :--------------------------------: | :--------------------------------: |
| ![ruby](/screenshot/vim-ember.png) | ![ruby](/screenshot/vim-flame.png) |

|         Night Coder Ash          |         Night Coder Charcoal          |
| :------------------------------: | :-----------------------------------: |
| ![ruby](/screenshot/vim-ash.png) | ![ruby](/screenshot/vim-charcoal.png) |
