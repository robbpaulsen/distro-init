This is a port of [Night Coder](https://marketplace.visualstudio.com/items?itemName=a5hk.night-coder) VS Code theme for [bat](https://github.com/sharkdp/bat). Built using [Theme Generator](https://github.com/a5hk/theme-generator)

## Screenshots

Screenshot of Windows Terminal (and WSL), displaying some Typescript code.

### Night Coder Ember

![typescript](/screenshot/bat-ember.png)

### Night Coder Flame

![typescript](/screenshot/bat-flame.png)

### Night Coder Ash

![typescript](/screenshot/bat-ash.png)

### Night Coder Charcoal

![typescript](/screenshot/bat-charcoal.png)
